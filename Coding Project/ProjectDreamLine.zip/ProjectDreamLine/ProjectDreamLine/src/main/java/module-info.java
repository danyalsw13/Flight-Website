module com.example.projectdreamline {
    requires javafx.controls;
    requires javafx.fxml;
    requires amadeus.java;
    requires javafx.web;
    requires java.sql;
    requires com.google.gson;
    requires java.net.http;


    opens com.example.projectdreamline to javafx.fxml;
    exports com.example.projectdreamline;
}