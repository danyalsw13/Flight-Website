package com.example.projectdreamline;

import java.util.HashMap;
import java.util.List;

public class Seat {
    private String seatNumber;
    private int xCoordinate;
    private int yCoordinate;
    private boolean available;

    private int width;

    private int length;

    private String seatAvailable;

    private HashMap<String, String> seatCharacteristicsMap;

    private List<String> characteristicsCodesList;

    private String seatPrice;

    private String cabin;

    // Constructor
    public Seat(String seatNumber, int xCoordinate, int yCoordinate, int width, int length
    , String seatAvailable, HashMap<String, String> seatCharacteristicsMap
    ,  List<String> characteristicsCodesList, String seatPrice, String cabin) {
        this.seatNumber = seatNumber;
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;
        this.seatAvailable = seatAvailable;
        this.width = width;
        this.length  = length;
        this.seatCharacteristicsMap = seatCharacteristicsMap;
        this.characteristicsCodesList = characteristicsCodesList;
        this.seatPrice = seatPrice;
        this.cabin = cabin;
    }

    public String getCabin() {
        return cabin;
    }
    public String getSeatPrice() {
        return seatPrice;
    }
    public List<String> getCharacteristicsCodesList() {
        return characteristicsCodesList;
    }
    public HashMap<String, String> getSeatCharacteristicsMap() {
        return seatCharacteristicsMap;
    }

    // Getters and setters
    public String getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public void setLength(int length) {
        this.length = length;
    }
    public void setWidth(int width) {
        this.width = width;
    }

    public int getLength() {
        return length;
    }

    public int getWidth() {
        return width;
    }

    public int getXCoordinate() {
        return xCoordinate;
    }

    public void setXCoordinate(int xCoordinate) {
        this.xCoordinate = xCoordinate;
    }

    public int getYCoordinate() {
        return yCoordinate;
    }

    public void setYCoordinate(int yCoordinate) {
        this.yCoordinate = yCoordinate;
    }

    public String getSeatAvailable() {
        return seatAvailable;
    }

    public void setSeatAvailable(String seatAvailable) {
        this.seatAvailable = seatAvailable;
    }
}