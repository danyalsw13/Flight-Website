package com.example.projectdreamline;

public class Price {
    private String currency;
    private double total;

    public Price(String currency, double total) {
        this.currency = currency;
        this.total = total;

    }

    //getters
    public String getCurrency() {
        return currency;
    }
    public double getTotal() {
        return total;
    }
}
