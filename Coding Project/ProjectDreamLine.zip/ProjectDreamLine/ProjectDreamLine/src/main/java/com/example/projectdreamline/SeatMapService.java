package com.example.projectdreamline;

import com.amadeus.Amadeus;
import com.amadeus.Params;
import com.amadeus.Travel;
import com.amadeus.resources.SeatMap;
import com.amadeus.resources.TripDetail;
import com.google.gson.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import javafx.scene.control.Alert;
import com.amadeus.resources.FlightOfferSearch;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.*;


public class SeatMapService {

    class SeatMapResponse {
        private SeatMap[] data;

        public SeatMap[] getData() {
            return data;
        }
        public void setData(SeatMap[] data) {
            this.data = data;
        }
    }
    private static final String AMADEUS_API_KEY = "ZPeflw5GDnxraU9hFpdk6UAYPQm7jsay";
    private static final String AMADEUS_SEAT_MAP_ENDPOINT = "https://test.api.amadeus.com/v1/shopping/seatmaps";


    public String constructSeatMapRequestBody(FlightOfferSearch flightOfferObject, String flightOrderId, String airlineCode, String flightNumber, String departureDate,
                                              String originLocationCode, String destinationLocationCode) {
        JsonObject requestBody = new JsonObject();

        // Create a JSON array for the flight offers data
        JsonArray flightOffersArray = new JsonArray();

        Gson gson = new Gson();

        String flightOfferJsonString = gson.toJson(flightOfferObject);

        flightOffersArray.add(gson.fromJson(flightOfferJsonString, JsonObject.class));

        requestBody.add("data", flightOffersArray);
        JsonObject params = new JsonObject();
        params.addProperty("include", "seats");
        requestBody.add("params", params);

        String requestBodyString = requestBody.toString();

        // Print the request body
    //    System.out.println("Request Body:");
   //     System.out.println(requestBodyString);
        return requestBodyString ;
    }
    public List<Seat> getSeatMapForFlight(String requestBody) throws Exception {
        Amadeus amadeus = Amadeus.builder("ZPeflw5GDnxraU9hFpdk6UAYPQm7jsay", "CQYi8IGjusYdu6Xb").build();

        String apiKey = "ZPeflw5GDnxraU9hFpdk6UAYPQm7jsay";
        String apiSecret = "CQYi8IGjusYdu6Xb";

        // Construct the request body with your flight data
       //  requestBody = "{\"data\": [{\"type\": \"flight-offer\", \"id\": \"17\", \"source\": \"GDS\", \"instantTicketingRequired\": false, \"disablePricing\": false, \"nonHomogeneous\": false, \"oneWay\": false, \"paymentCardRequired\": false, \"lastTicketingDate\": \"2024-04-21\", \"numberOfBookableSeats\": 9, \"itineraries\": [{\"duration\": \"PT7H25M\", \"segments\": [{\"departure\": {\"iataCode\": \"JFK\", \"terminal\": \"8\", \"at\": \"2024-04-21T20:45:00\"}, \"arrival\": {\"iataCode\": \"MAD\", \"terminal\": \"4S\", \"at\": \"2024-04-22T10:10:00\"}, \"carrierCode\": \"IB\", \"number\": \"6252\", \"aircraft\": {\"code\": \"359\"}, \"operating\": {\"carrierCode\": \"IB\"}, \"duration\": \"PT7H25M\", \"id\": \"93\", \"numberOfStops\": 0, \"blacklistedInEU\": false}]}], \"price\": {\"currency\": \"USD\", \"total\": \"591.30\", \"base\": \"354.00\", \"fees\": [{\"amount\": \"0.00\", \"type\": \"SUPPLIER\"}, {\"amount\": \"0.00\", \"type\": \"TICKETING\"}], \"grandTotal\": \"591.30\", \"additionalServices\": [{\"amount\": \"85.10\", \"type\": \"CHECKED_BAGS\"}]}," +
       //         "\"pricingOptions\": {\"includedCheckedBagsOnly\": true, \"fareType\": [\"PUBLISHED\"], \"refundableFare\": false, \"noRestrictionFare\": false, \"noPenaltyFare\": false}, \"validatingAirlineCodes\": [\"IB\"], \"travelerPricings\": [{\"travelerId\": \"1\", \"fareOption\": \"STANDARD\", \"travelerType\": \"ADULT\", \"price\": {\"currency\": \"USD\", \"total\": \"591.30\", \"base\": \"354.00\"}, \"fareDetailsBySegment\": [{\"segmentId\": \"93\", \"cabin\": \"ECONOMY\", \"fareBasis\": \"OKN0Z4M5\", \"brandedFare\": \"OPTIMA\", \"class\": \"O\", \"isAllotment\": false, \"includedCheckedBags\": {\"quantity\": 1, \"weight\": 0}, \"amenities\": [{\"description\": \"SECOND CHECKED BAG\", \"isChargeable\": true, \"amenityType\": \"BAGGAGE\"}, {\"description\": \"THIRD CHECKED BAG\", \"isChargeable\": true, \"amenityType\": \"BAGGAGE\"}, {\"description\": \"MEAL\", \"isChargeable\": false, \"amenityType\": \"MEAL\"}, {\"description\": \"SNACK OR DRINK\", \"isChargeable\": true, \"amenityType\": \"MEAL\"}, {\"description\": \"WIFI CONNECTION\", \"isChargeable\": true, \"amenityType\": \"TRAVEL_SERVICES\"}]}]}]}]}";

            // Construct the HTTP client
            HttpClient client = HttpClient.newHttpClient();

            String accessToken = getAccessToken();
          //  System.out.println(accessToken);
            // Construct the HTTP request
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://test.api.amadeus.com/v1/shopping/seatmaps"))
                    .header("Authorization", "Bearer " + accessToken)
                    .header("Content-Type", "application/json")
                    .POST(BodyPublishers.ofString(requestBody))
                    .build();

            // Send the request and get the response
            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
            String responseBody = response.body();

            System.out.println(responseBody);

            Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(responseBody, JsonObject.class);

        JsonArray dataArray = jsonObject.getAsJsonArray("data");
        JsonObject dataObject = dataArray.get(0).getAsJsonObject();

        JsonArray decksArray = dataObject.getAsJsonArray("decks");

        List<Seat> seatData = new ArrayList<>();

        for (int i = 0; i < decksArray.size(); i++) {
            JsonObject deckObject = decksArray.get(i).getAsJsonObject();
            String deckType = deckObject.get("deckType").getAsString();
            JsonObject deckConfiguration = deckObject.getAsJsonObject("deckConfiguration");
            int width = deckConfiguration.get("width").getAsInt();
            int length = deckConfiguration.get("length").getAsInt();

            JsonArray seatsArray = deckObject.getAsJsonArray("seats");
            for (int j = 0; j < seatsArray.size(); j++) {
                JsonObject seatObject = seatsArray.get(j).getAsJsonObject();
                JsonArray travelerPricingArray = seatObject.getAsJsonArray("travelerPricing");
                JsonObject dictionariesObject = jsonObject.getAsJsonObject("dictionaries");

                JsonObject seatCharacteristicsObject = dictionariesObject.getAsJsonObject("seatCharacteristics");

            //    System.out.println("seatChar: " + seatCharacteristicsObject);
                HashMap<String, String> seatCharacteristicsMap = new HashMap<>();
                List<String> characteristicsCodesList = new ArrayList<>();

                for (Map.Entry<String, JsonElement> entry : seatCharacteristicsObject.entrySet()) {
                    // Get the code and description
                    String code = entry.getKey();
                    String description = entry.getValue().getAsString();
                    // Store the code-description pair in the HashMap
                    seatCharacteristicsMap.put(code, description);
                }

                String seatAvailabilityStatus = "";
                String seatPrices = "";
                for (int k = 0; k < travelerPricingArray.size(); k++) {
                    JsonObject travelerPricingObject = travelerPricingArray.get(k).getAsJsonObject();
                    seatAvailabilityStatus  = travelerPricingObject.get("seatAvailabilityStatus").getAsString();
                    JsonElement priceElement = travelerPricingObject.get("price");
                    if (priceElement != null && priceElement.isJsonObject()) {
                        JsonObject priceObject = priceElement.getAsJsonObject();
                        seatPrices = priceObject.get("total").getAsString();
                    } else {
                        seatPrices = "0";
                    }

                }
               // System.out.println("SeatPrice: " + seatPrices);

                String cabin = seatObject.get("cabin").getAsString();
                String seatNumber = seatObject.get("number").getAsString();
              // String seatAvailable = seatObject.get("seatAvailabilityStatus").getAsString();
                JsonArray characteristicsCodes = seatObject.getAsJsonArray("characteristicsCodes");
                for (JsonElement element : characteristicsCodes) {
                    String code = element.getAsString();
                    characteristicsCodesList.add(code);
                }

                JsonObject coordinatesObject = seatObject.getAsJsonObject("coordinates");
                int x = coordinatesObject.get("x").getAsInt();
                int y = coordinatesObject.get("y").getAsInt();


                // Extract other seat attributes as needed
                Seat seat = new Seat(seatNumber, x, y, width, length, seatAvailabilityStatus,
                        seatCharacteristicsMap, characteristicsCodesList, seatPrices, cabin) ;
                seatData.add(seat);


                // Process the seat data
         //       System.out.println("Seat Availability Status: " + seatAvailabilityStatus);
        //        System.out.println("Seat: " + cabin + " " + seatNumber);
        //        System.out.println("Characteristics Codes: " + characteristicsCodes);
         //       System.out.println("x: " + x + " y: " + y);

            }
        }


        System.out.println("Response code: " + response.statusCode());
            System.out.println("Response body: " + response.body());


        return seatData;

    }

        public static String getAccessToken() throws Exception {
        String apiKey = "ZPeflw5GDnxraU9hFpdk6UAYPQm7jsay";
        String apiSecret = "CQYi8IGjusYdu6Xb";
        String TOKEN_URL = "https://test.api.amadeus.com/v1/security/oauth2/token";

        // Construct the credentials string by encoding the client ID and secret
        String credentials = apiKey + ":" + apiSecret;
        String encodedCredentials = Base64.getEncoder().encodeToString(credentials.getBytes());

        // Construct the request body for obtaining the access token
        String requestBody = "grant_type=client_credentials";

        // Construct the HTTP request
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(TOKEN_URL))
                .header("Authorization", "Basic " + encodedCredentials)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(BodyPublishers.ofString(requestBody))
                .build();

        // Send the request and obtain the response
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            // Parse the response JSON to extract the access token
            String responseBody = response.body();
            int startIndex = responseBody.indexOf("\"access_token\":\"");
            if (startIndex != -1) {
                startIndex += "\"access_token\":\"".length();
                int endIndex = responseBody.indexOf("\"", startIndex);
                if (endIndex != -1) {
                    String accessToken = responseBody.substring(startIndex, endIndex);
                    return accessToken;
                }
            }
            JsonObject jsonObject = JsonParser.parseString(responseBody).getAsJsonObject();

            String accessToken = jsonObject.get("access_token").getAsString();
            System.out.println("ACCESS TOKEN: " + accessToken);

            return accessToken;

            // If the access token could not be extracted from the response body, throw an exception
          //  throw new RuntimeException("Failed to extract access token from response body: " + responseBody);
        } else {
            // If the response is not successful, throw an exception or handle the error accordingly
            throw new RuntimeException("Failed to obtain access token. Status code: " + response.statusCode());
        }
    }

    public void displaySeatMap(GridPane gridPane, List<Seat> seatData) {

        // Create a new grid pane for the seat map display
        //GridPane gridPane = new GridPane();
    //    gridPane.setPadding(new Insets(10));
     //  gridPane.setHgap(10); // Adjust horizontal gap between cells
    //   gridPane.setVgap(10); // Adjust vertical gap between cells

     //   gridPane.setAlignment(Pos.CENTER);

        // Add seats to the grid pane
        for (Seat seat : seatData) {
            // Create a rectangle representing the seat
            Rectangle seatRect = new Rectangle(30, 30); // Adjust dimensions as needed
         //   seatRect.setFill(Color.LIGHTGRAY);
            seatRect.setStroke(Color.BLACK);

            if ((seat.getSeatPrice().equals("0") || seat.getSeatPrice().equals("0.00"))  && seat.getSeatAvailable().equals("AVAILABLE")) {
                seatRect.setFill(Color.YELLOW);
            } else {
                switch (seat.getSeatAvailable()) {
                    case "OCCUPIED":
                        seatRect.setFill(Color.rgb(255, 0, 0, 0.5));
                        break;
                    case "BLOCKED":
                        seatRect.setFill(Color.rgb(128, 128, 128, 0.5));
                        break;
                    case "AVAILABLE":
                        seatRect.setFill(Color.rgb(0, 255, 0, 0.5));
                        break;
                    default:
                        seatRect.setFill(Color.LIGHTGRAY); // Default color
                        break;
                }

            }

            // Create a label for the seat number
            Label seatLabel = new Label(seat.getSeatNumber());
            seatLabel.setStyle("-fx-font-size: 10pt;"); // Adjust font size as needed

            // Stack the rectangle and label to display the seat
            StackPane seatNode = new StackPane(seatRect, seatLabel);

            seatNode.setOnMouseEntered(event -> {
                seatNode.setCursor(Cursor.HAND);
                seatRect.setOpacity(0.6);

            });
            seatNode.setOnMouseExited(event -> {
                seatRect.setOpacity(1.0); // Reset opacity to full
            });

            // Add event handler to display seat information when clicked
            seatNode.setOnMouseClicked(event -> {
                showSeatInfo(seat);
            });
            // Add the seat node to the grid pane at the specified row and column
            gridPane.add(seatNode, seat.getYCoordinate(), seat.getXCoordinate());

        }

        // Create a scroll pane and set its content to the grid pane
    //    ScrollPane scrollPane = new ScrollPane(gridPane);
    //    scrollPane.setFitToWidth(true);
    //    scrollPane.setFitToHeight(true);
    //    scrollPane.setPrefSize(800, 600);

        // Create a scene with the grid pane
    //    Scene scene = new Scene(scrollPane);

        // Create a new stage for the seat map display
   //     Stage stage = new Stage();
  //      stage.setTitle("Seat Map");
  //      stage.setScene(scene);
   //     stage.show();
    }

    private void showSeatInfo(Seat seat) {
        // Create a label to display seat information
        HashMap<String, String> seatCharacteristicsMap = seat.getSeatCharacteristicsMap();

        List<String> characteristicsCodesList = seat.getCharacteristicsCodesList();

        StringBuilder charInfo = new StringBuilder();
        for (String code: characteristicsCodesList) {
            if (seatCharacteristicsMap.containsKey(code)) {
                String description = seatCharacteristicsMap.get(code);
                charInfo.append(code).append(": ").append(description).append("\n");
            }
        }
        String price = "";
        if (seat.getSeatPrice() == "0") {
            price = "FREE";
        } else {
            price = seat.getSeatPrice();
        }
        Label seatLabel = new Label(seat.getSeatNumber());
        seatLabel.setStyle("-fx-font-size: 10pt; -fx-font-weight: bold");

        Label infoLabel = new Label("Cabin: " + seat.getCabin() + "\n"
                + "Seat Number: " + seat.getSeatNumber() + "\n"
                + "Availability: " + seat.getSeatAvailable() + "\n"
                + "Seat Price: USD " + price + "\n"
                + "Comfort Detail ⤦" + "\n"
                + charInfo.toString());


        // Apply styling to the label
        infoLabel.setStyle("-fx-font-size: 14pt; " +
                "-fx-text-fill: #333333;"); // Dark gray text color

        // Create a new stage for the seat information display
        Stage infoStage = new Stage();
        infoStage.initModality(Modality.APPLICATION_MODAL);
        infoStage.setTitle("Seat Information");

        // Create a VBox to hold the label
        VBox vbox = new VBox(10); // Set spacing between nodes
        vbox.getChildren().add(infoLabel);
        //vbox.setAlignment(Pos.CENTER); // Center the VBox

        // Apply styling to the VBox
        vbox.setStyle("-fx-background-color: #f0f0f0; " + // Light gray background color
                "-fx-padding: 20px;" +
                "-fx-margin-right: 20px"); // Padding around the VBox

        // Create a scene with the VBox
        Scene scene = new Scene(vbox, 300, 230); // Adjust size as needed
        infoStage.setScene(scene);

        // Move the scene to the right side of the primary screen
        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
        double screenWidth = primaryScreenBounds.getWidth();
        double screenHeight = primaryScreenBounds.getHeight();

        double sceneWidth = 300; // Width of the scene
        double sceneHeight = 230; // Height of the scene

        double sceneX = screenWidth - sceneWidth - 390;; // Adjust the value as needed to leave space from the right side
        double sceneY = (screenHeight - sceneHeight) / 2; // Center vertically

        infoStage.setX(sceneX);
        infoStage.setY(sceneY);
        // Show the stage
        infoStage.show();
    }

    public void displayErrorMessage(String message) {
        // Create an alert dialog to display the error message
        Alert alert = new Alert(Alert.AlertType.ERROR);
        System.out.println("HERE");
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);

        // Display the alert dialog
        alert.showAndWait();
    }
}
