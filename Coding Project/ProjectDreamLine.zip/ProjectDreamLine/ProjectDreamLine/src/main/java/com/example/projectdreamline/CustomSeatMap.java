package com.example.projectdreamline;

import com.amadeus.resources.SeatMap;

import java.util.List;

public class CustomSeatMap extends SeatMap {
    private List<Seat> seats;

    public List<Seat> getSeats() {
        return seats;
    }

    public void setSeats(List<Seat> seats) {
        this.seats = seats;
    }
}
